<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\Models\Usuarios;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function showLoginForm()
{
    return view('sysadmin.index');
}

public function login(Request $request)
{
    $credentials = [
        'email' => $request->input('email'),
        'password' => $request->input('password'), // Encripta la contraseña con MD5
    ];
    // dd($credentials); 
    if (Auth::attempt($credentials)) {
        return redirect()->route('panel'); // Redirige a la vista panel.blade.php
    } else {
        return redirect()->back()->withErrors(['email' => 'Credenciales incorrectas']);
    }
}
}
