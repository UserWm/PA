<?php

namespace App\Http\Controllers;
use App\Models\Reservaciones;
use App\Models\Canchas;

use Illuminate\Http\Request;

class ReservacionesController extends Controller
{
   
public function index()
{
    $reservaciones = Reservaciones::with('cancha')->get();
    return view('welcome', compact('reservaciones'));
}
}
